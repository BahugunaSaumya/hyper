// src/components/AdminDashboard.tsx
"use client";

import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { ADMIN_EMAILS, ADMIN_UIDS } from "@/config/admin";

type KPI = { ordersCount: number; usersCount: number; revenue: number };
type Order = any;

async function safeJson(res: Response) {
  // never throw on .json() — return null if body is empty or not JSON
  try {
    const ct = res.headers.get("content-type") || "";
    if (!ct.includes("application/json")) {
      // try anyway; if it fails, return null
      return await res.json().catch(() => null);
    }
    return await res.json();
  } catch {
    return null;
  }
}

export default function AdminDashboard() {
  const { user } = useAuth();
  const [token, setToken] = useState<string>("");
  const [kpi, setKpi] = useState<KPI | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [csvRows, setCsvRows] = useState<string[][]>([]);
  const [savingCsv, setSavingCsv] = useState(false);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  const allowed = useMemo(() => {
    if (!user) return false;
    return (user.email && ADMIN_EMAILS.includes(user.email)) || ADMIN_UIDS.includes(user.uid);
  }, [user]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        if (!user || !allowed) { setLoading(false); return; }
        const tok = await user.getIdToken();
        if (!mounted) return;
        setToken(tok);

        const [sRes, oRes, pRes] = await Promise.all([
          fetch("/api/admin/summary", { headers: { authorization: `Bearer ${tok}` } }),
          fetch("/api/admin/orders?limit=50", { headers: { authorization: `Bearer ${tok}` } }),
          fetch("/api/admin/products", { headers: { authorization: `Bearer ${tok}` } }),
        ]);

        const s = await safeJson(sRes);
        const o = await safeJson(oRes);
        const p = await safeJson(pRes);

        if (sRes.ok && s) setKpi(s as KPI);
        if (oRes.ok && o) setOrders((o as any).orders || []);
        if (pRes.ok && p) {
          setCsvHeaders((p as any).headers || []);
          setCsvRows((p as any).rows || []);
        }

        if (!sRes.ok || !oRes.ok || !pRes.ok) {
          setErr("Some admin data failed to load. Try again or check server logs.");
        }
      } catch (e: any) {
        setErr(e?.message || "Failed to load admin data.");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, [user, allowed]);

  if (!user) {
    return (
      <div className="min-h-[60vh] grid place-items-center text-sm text-gray-600">
        Please log in.
      </div>
    );
  }
  if (!allowed) {
    return (
      <div className="min-h-[60vh] grid place-items-center text-sm text-gray-600">
        You do not have access to this page.
      </div>
    );
  }
  if (loading) {
    return (
      <div className="min-h-[60vh] grid place-items-center text-sm text-gray-600">
        Loading admin data…
      </div>
    );
  }

  async function saveCsv() {
    try {
      setSavingCsv(true);
      const res = await fetch("/api/admin/products", {
        method: "POST",
        headers: { "Content-Type": "application/json", authorization: `Bearer ${token}` },
        body: JSON.stringify({ headers: csvHeaders, rows: csvRows }),
      });
      const body = await safeJson(res);
      if (!res.ok) throw new Error(body?.error || "Failed to save CSV");
      alert("Products CSV updated.");
    } catch (e: any) {
      alert(e?.message || "Failed to save CSV");
    } finally {
      setSavingCsv(false);
    }
  }

  return (
    <main className="bg-white text-black">
      <div style={{ height: "calc(var(--nav-h, 88px))" }} />

      <section className="max-w-6xl mx-auto px-6 pt-10 pb-6">
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-wide">
          Admin Dashboard
        </h1>
        <p className="text-sm text-gray-600 mt-1">
          Welcome, {user.email}.
        </p>
        {err && <p className="mt-3 text-sm text-red-600">{err}</p>}
      </section>

      {/* KPI cards */}
      <section className="max-w-6xl mx-auto px-4 md:px-6 grid grid-cols-1 sm:grid-cols-3 gap-4 pb-8">
        <Card title="Orders">
          <div className="text-2xl font-extrabold">{kpi?.ordersCount ?? "—"}</div>
        </Card>
        <Card title="Users">
          <div className="text-2xl font-extrabold">{kpi?.usersCount ?? "—"}</div>
        </Card>
        <Card title="Revenue (INR)">
          <div className="text-2xl font-extrabold">
            ₹ {Number(kpi?.revenue || 0).toLocaleString("en-IN")}
          </div>
        </Card>
      </section>

      {/* Orders table */}
      <section className="max-w-6xl mx-auto px-4 md:px-6 pb-12">
        <div className="rounded-2xl border border-gray-200 overflow-hidden">
          <header className="px-5 py-3 border-b text-sm font-semibold">Recent Orders</header>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <Th>Order ID</Th>
                  <Th>Customer</Th>
                  <Th>Email</Th>
                  <Th>Total</Th>
                  <Th>Status</Th>
                  <Th>Placed</Th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {orders.map((o: any) => (
                  <tr key={o.id}>
                    <Td className="font-mono">{o.id}</Td>
                    <Td>{o.customer?.name || "—"}</Td>
                    <Td className="break-all">{o.customer?.email || "—"}</Td>
                    <Td>₹ {Number(o?.amounts?.total || 0).toLocaleString("en-IN")}</Td>
                    <Td>{o.status || "—"}</Td>
                    <Td>
                      {o.createdAt?.toDate
                        ? o.createdAt.toDate().toLocaleString()
                        : (o.placedAt || "—")}
                    </Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* CSV editor */}
      <section className="max-w-6xl mx-auto px-4 md:px-6 pb-20">
        <div className="rounded-2xl border border-gray-200 overflow-hidden">
          <header className="px-5 py-3 border-b text-sm font-semibold flex items-center justify-between">
            <span>Products (CSV)</span>
            <button
              onClick={saveCsv}
              disabled={savingCsv}
              className="px-4 py-2 rounded-full border hover:bg-black hover:text-white transition text-sm"
            >
              {savingCsv ? "Saving…" : "Save CSV"}
            </button>
          </header>

          <div className="overflow-x-auto">
            <table className="min-w-full text-xs sm:text-sm">
              <thead className="bg-gray-50">
                <tr>
                  {csvHeaders.map((h, i) => (
                    <Th key={i}>{h}</Th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y">
                {csvRows.map((row, rIdx) => (
                  <tr key={rIdx}>
                    {csvHeaders.map((_, cIdx) => (
                      <Td key={cIdx} className="p-1 sm:p-2">
                        <input
                          value={row[cIdx] ?? ""}
                          onChange={(e) => {
                            const v = e.target.value;
                            setCsvRows((old) => {
                              const next = old.map((r) => [...r]);
                              while (next[rIdx].length < csvHeaders.length) next[rIdx].push("");
                              next[rIdx][cIdx] = v;
                              return next;
                            });
                          }}
                          className="w-full px-2 py-1 border rounded-md"
                        />
                      </Td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* quick add row */}
          <div className="p-4 border-t flex items-center justify-end">
            <button
              onClick={() => setCsvRows((old) => [...old, new Array(csvHeaders.length).fill("")])}
              className="px-4 py-2 rounded-full border text-sm hover:bg-black hover:text-white transition"
            >
              + Add Row
            </button>
          </div>
        </div>
        <p className="mt-2 text-xs text-gray-500">Note: A “quantity” column is ensured automatically.</p>
      </section>
    </main>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-gray-200 p-5">
      <div className="text-xs text-gray-600 mb-1">{title}</div>
      {children}
    </div>
  );
}
function Th({ children }: { children: React.ReactNode }) {
  return <th className="text-left px-4 py-2 font-semibold">{children}</th>;
}
function Td({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <td className={`px-4 py-2 align-top ${className}`}>{children}</td>;
}
