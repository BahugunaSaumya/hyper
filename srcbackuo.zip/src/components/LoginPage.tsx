"use client";

import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { ADMIN_EMAILS} from "@/config/admin";

type KPI = { ordersCount: number; usersCount: number; revenueINR: number };
type Order = any;

export default function AdminDashboard() {
  const { user } = useAuth();

  const [token, setToken] = useState<string>("");
  const [kpi, setKpi] = useState<KPI | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [csvRows, setCsvRows] = useState<string[][]>([]);
  const [savingCsv, setSavingCsv] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const allowed = useMemo(() => {
    if (!user) return false;
    return (
      (!!user.email && ADMIN_EMAILS.includes(user.email)) ||
      ADMIN_UIDS.includes(user.uid)
    );
  }, [user]);

  useEffect(() => {
    let cancelled = false;

    const safeJson = async (res: Response) => {
      const ct = res.headers.get("content-type") || "";
      if (!res.ok) {
        // Try to read something helpful
        const text = await res.text().catch(() => "");
        throw new Error(
          `HTTP ${res.status} ${res.statusText}${
            text ? ` — ${text.slice(0, 200)}` : ""
          }`
        );
      }
      if (!ct.includes("application/json")) {
        const text = await res.text().catch(() => "");
        if (!text.trim()) return null;
        try {
          return JSON.parse(text);
        } catch {
          throw new Error("Response was not JSON.");
        }
      }
      try {
        return await res.json();
      } catch {
        return null;
      }
    };

    (async () => {
      if (!user || !allowed) {
        setLoading(false);
        return;
      }
      try {
        setError(null);

        const tok = await user.getIdToken();
        if (cancelled) return;
        setToken(tok);

        const [sRes, oRes, pRes] = await Promise.allSettled([
          fetch("/api/admin/summary", {
            headers: { authorization: `Bearer ${tok}` },
            cache: "no-store",
          }),
          fetch("/api/admin/orders?limit=50", {
            headers: { authorization: `Bearer ${tok}` },
            cache: "no-store",
          }),
          fetch("/api/admin/products", {
            headers: { authorization: `Bearer ${tok}` },
            cache: "no-store",
          }),
        ]);

        if (sRes.status === "fulfilled") {
          const data = await safeJson(sRes.value);
          if (!cancelled && data) setKpi(data as KPI);
        } else {
          throw sRes.reason;
        }

        if (oRes.status === "fulfilled") {
          const data = (await safeJson(oRes.value)) as any;
          if (!cancelled) setOrders(Array.isArray(data?.orders) ? data.orders : []);
        } else {
          throw oRes.reason;
        }

        if (pRes.status === "fulfilled") {
          const data = (await safeJson(pRes.value)) as any;
          if (!cancelled) {
            const headers: string[] = Array.isArray(data?.headers) ? data.headers : [];
            const rows: string[][] = Array.isArray(data?.rows) ? data.rows : [];
            // Ensure "quantity" column exists client-side too
            const nextHeaders = ensureQuantityHeader(headers);
            const nextRows = rows.map((r) => normalizeRowLength(r, nextHeaders.length));
            setCsvHeaders(nextHeaders);
            setCsvRows(nextRows);
          }
        } else {
          throw pRes.reason;
        }

      } catch (e: any) {
        if (!cancelled) {
          console.error("[admin] load failed:", e);
          setError(e?.message || "Failed to load admin data.");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [user, allowed]);

  if (!user) {
    return (
      <div className="min-h-[60vh] grid place-items-center text-sm text-gray-600">
        Please log in.
      </div>
    );
  }

  if (!allowed) {
    return (
      <div className="min-h-[60vh] grid place-items-center text-sm text-gray-600">
        You do not have access to this page.
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-[60vh] grid place-items-center text-sm text-gray-600">
        Loading admin data…
      </div>
    );
  }

  async function saveCsv() {
    try {
      setSavingCsv(true);
      const res = await fetch("/api/admin/products", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          headers: ensureQuantityHeader(csvHeaders),
          rows: csvRows.map((r) => normalizeRowLength(r, csvHeaders.length)),
        }),
      });
      if (!res.ok) {
        const t = await res.text().catch(() => "");
        throw new Error(t || "Failed to save CSV");
      }
      alert("Products CSV updated.");
    } catch (e: any) {
      alert(e?.message || "Failed to save CSV");
    } finally {
      setSavingCsv(false);
    }
  }

  return (
    <main className="bg-white text-black">
      <div style={{ height: "calc(var(--nav-h, 88px))" }} />

      <section className="max-w-6xl mx-auto px-6 pt-10 pb-6">
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-wide">
          Admin Dashboard
        </h1>
        <p className="text-sm text-gray-600 mt-1">Welcome, {user.email}.</p>
        {error && (
          <p className="mt-2 text-sm text-red-600">
            {error}
          </p>
        )}
      </section>

      {/* KPI cards */}
      <section className="max-w-6xl mx-auto px-4 md:px-6 grid grid-cols-1 sm:grid-cols-3 gap-4 pb-8">
        <Card title="Orders">
          <div className="text-2xl font-extrabold">{kpi?.ordersCount ?? "—"}</div>
        </Card>
        <Card title="Users">
          <div className="text-2xl font-extrabold">{kpi?.usersCount ?? "—"}</div>
        </Card>
        <Card title="Revenue (INR)">
          <div className="text-2xl font-extrabold">
            ₹ {Number(kpi?.revenueINR || 0).toLocaleString("en-IN")}
          </div>
        </Card>
      </section>

      {/* Orders table */}
      <section className="max-w-6xl mx-auto px-4 md:px-6 pb-12">
        <div className="rounded-2xl border border-gray-200 overflow-hidden">
          <header className="px-5 py-3 border-b text-sm font-semibold">
            Recent Orders
          </header>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <Th>Order ID</Th>
                  <Th>Customer</Th>
                  <Th>Email</Th>
                  <Th>Total</Th>
                  <Th>Status</Th>
                  <Th>Placed</Th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {orders.map((o: any) => (
                  <tr key={o.id}>
                    <Td className="font-mono">{o.id}</Td>
                    <Td>{o.customer?.name || "—"}</Td>
                    <Td className="break-all">{o.customer?.email || "—"}</Td>
                    <Td>
                      ₹ {Number(o?.amounts?.total || 0).toLocaleString("en-IN")}
                    </Td>
                    <Td>{o.status || "—"}</Td>
                    <Td>
                      {o.createdAt?.toDate
                        ? o.createdAt.toDate().toLocaleString()
                        : o.placedAt || "—"}
                    </Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* CSV editor */}
      <section className="max-w-6xl mx-auto px-4 md:px-6 pb-20">
        <div className="rounded-2xl border border-gray-200 overflow-hidden">
          <header className="px-5 py-3 border-b text-sm font-semibold flex items-center justify-between">
            <span>Products (CSV)</span>
            <button
              onClick={saveCsv}
              disabled={savingCsv}
              className="px-4 py-2 rounded-full border hover:bg-black hover:text-white transition text-sm"
            >
              {savingCsv ? "Saving…" : "Save CSV"}
            </button>
          </header>

          <div className="overflow-x-auto">
            <table className="min-w-full text-xs sm:text-sm">
              <thead className="bg-gray-50">
                <tr>
                  {csvHeaders.map((h, i) => (
                    <Th key={i}>{h}</Th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y">
                {csvRows.map((row, rIdx) => (
                  <tr key={rIdx}>
                    {csvHeaders.map((_, cIdx) => (
                      <Td key={cIdx} className="p-1 sm:p-2">
                        <input
                          value={row[cIdx] ?? ""}
                          onChange={(e) => {
                            const v = e.target.value;
                            setCsvRows((old) => {
                              const next = old.map((r) => [...r]);
                              while (next[rIdx].length < csvHeaders.length)
                                next[rIdx].push("");
                              next[rIdx][cIdx] = v;
                              return next;
                            });
                          }}
                          className="w-full px-2 py-1 border rounded-md"
                        />
                      </Td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* quick add row */}
          <div className="p-4 border-top flex items-center justify-end">
            <button
              onClick={() =>
                setCsvRows((old) => [...old, new Array(csvHeaders.length).fill("")])
              }
              className="px-4 py-2 rounded-full border text-sm hover:bg-black hover:text-white transition"
            >
              + Add Row
            </button>
          </div>
        </div>
        <p className="mt-2 text-xs text-gray-500">
          Note: A “quantity” column is ensured automatically.
        </p>
      </section>
    </main>
  );
}

function ensureQuantityHeader(headers: string[]) {
  const hasQty = headers.some((h) => h.trim().toLowerCase() === "quantity");
  return hasQty ? headers : [...headers, "quantity"];
}
function normalizeRowLength(row: string[], length: number) {
  const next = [...row];
  while (next.length < length) next.push("");
  if (next.length > length) next.length = length;
  return next;
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-gray-200 p-5">
      <div className="text-xs text-gray-600 mb-1">{title}</div>
      {children}
    </div>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return <th className="text-left px-4 py-2 font-semibold">{children}</th>;
}
function Td({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return <td className={`px-4 py-2 align-top ${className}`}>{children}</td>;
}
