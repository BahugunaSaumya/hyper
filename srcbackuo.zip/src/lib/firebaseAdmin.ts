// src/lib/firebaseAdmin.ts
import type { ServiceAccount } from "firebase-admin";
import * as admin from "firebase-admin";

let app: admin.app.App | null = null;

function getServiceAccountFromEnv(): ServiceAccount | null {
  // Option A: Entire JSON in one env var
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT;
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      return parsed as ServiceAccount;
    } catch {
      console.error("[firebaseAdmin] Failed to parse FIREBASE_SERVICE_ACCOUNT JSON");
    }
  }
  return null;
}

export function getAdminApp() {
  if (app) return app;

  const sa = getServiceAccountFromEnv();
  const hasApp = admin.apps && admin.apps.length > 0;

  if (!hasApp) {
    if (sa) {
      app = admin.initializeApp({
        credential: admin.credential.cert(sa),
        projectId: process.env.FIREBASE_PROJECT_ID || sa.projectId,
      });
    } else {
      // Fallback: will only work if Netlify runtime has ADC configured
      app = admin.initializeApp({
        credential: admin.credential.applicationDefault(),
        projectId: process.env.FIREBASE_PROJECT_ID,
      });
    }
  } else {
    app = admin.app();
  }

  return app!;
}

export function getDb() {
  return getAdminApp().firestore();
}
