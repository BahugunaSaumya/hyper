// src/app/dashboard/page.tsx
"use client";

import { useAuth } from "@/context/AuthContext";
import { useEffect, useState } from "react";

export default function DashboardPage() {
  const { user, loading, profile } = useAuth() as any;
  const [orders, setOrders] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;

    // Fetch orders from sessionStorage (temporary solution)
    try {
      const stored = sessionStorage.getItem("userOrders");
      if (stored) {
        setOrders(JSON.parse(stored));
      }
    } catch (e) {
      console.error("Failed to load orders", e);
    }
  }, [user]);

  if (loading) {
    return (
      <main className="min-h-[50vh] grid place-items-center">
        <p>Loading your dashboard...</p>
      </main>
    );
  }

  if (!user) {
    return (
      <main className="min-h-[50vh] grid place-items-center">
        <p>Please log in to view your dashboard.</p>
      </main>
    );
  }

  return (
    <main className="max-w-4xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold mb-6">Welcome, {user.email}</h1>

      <section className="mb-10">
        <h2 className="text-xl font-semibold mb-4">Your Orders</h2>
        {orders.length === 0 ? (
          <p className="text-gray-500">No orders yet.</p>
        ) : (
          <ul className="space-y-4">
            {orders.map((order, idx) => (
              <li key={idx} className="p-4 border rounded-lg">
                <p>Order ID: {order.id}</p>
                <p>Total: ₹{order.total}</p>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-4">Edit Address</h2>
        <form className="space-y-3">
          <input type="text" placeholder="Street Address" className="w-full p-2 border rounded" />
          <input type="text" placeholder="City" className="w-full p-2 border rounded" />
          <input type="text" placeholder="State" className="w-full p-2 border rounded" />
          <input type="text" placeholder="Postal Code" className="w-full p-2 border rounded" />
          <button type="submit" className="bg-black text-white px-4 py-2 rounded">Save</button>
        </form>
      </section>
    </main>
  );
}
