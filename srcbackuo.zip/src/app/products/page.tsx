import ProductsSection from "@/components/ProductsSection";
export default function ProductsPage() {
  return <main className="offset-header"><ProductsSection /></main>;
}
