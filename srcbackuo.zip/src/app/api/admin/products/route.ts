// src/app/api/admin/products/route.ts
import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "../_lib/auth";
import { getDb } from "@/lib/firebaseAdmin";

// Normalized columns we keep compatible with the CSV-editor UI
const DEFAULT_HEADERS = ["id", "name", "price", "size", "image", "quantity"] as const;
type Col = (typeof DEFAULT_HEADERS)[number];

function toRowsFromDocs(docs: FirebaseFirestore.QueryDocumentSnapshot[]): string[][] {
  return docs.map((d) => {
    const data = d.data() as any;
    const row: string[] = [];
    DEFAULT_HEADERS.forEach((h) => {
      if (h === "id") row.push(d.id);
      else row.push(data?.[h] != null ? String(data[h]) : "");
    });
    return row;
  });
}

function toObjectsFromRows(headers: string[], rows: string[][]) {
  // Normalize to our default schema; 'id' will be used as doc ID, others as fields
  // Unknown columns are also copied into the document for forward-compat.
  const lowerToHeader: Record<string, string> = {};
  headers.forEach((h) => (lowerToHeader[h.toLowerCase()] = h));

  const headerIndex: Record<string, number> = {};
  headers.forEach((h, i) => (headerIndex[h] = i));

  const ensure = (key: string) =>
    headerIndex[key] ?? headerIndex[lowerToHeader[key]] ?? -1;

  const out: Array<{ id: string; data: Record<string, any> }> = [];

  for (const row of rows) {
    const idIdx = ensure("id");
    const id = idIdx >= 0 ? (row[idIdx] || "").trim() : "";
    if (!id) continue;

    const data: Record<string, any> = {};
    headers.forEach((h) => {
      if (h === "id") return;
      const i = headerIndex[h];
      data[h] = i >= 0 ? row[i] ?? "" : "";
    });

    // Fix numeric columns if needed
    if (data.price != null && data.price !== "") {
      const n = Number(String(data.price).replace(/[^\d.]/g, ""));
      if (!Number.isNaN(n)) data.price = n;
    }
    if (data.quantity != null && data.quantity !== "") {
      const q = parseInt(String(data.quantity), 10);
      if (!Number.isNaN(q)) data.quantity = q;
    }

    out.push({ id, data });
  }

  return out;
}

export async function GET(req: NextRequest) {
  const unauthorized = await requireAdmin(req);
  if (unauthorized) return unauthorized;

  try {
    const db = getDb();
    const snap = await db.collection("products").orderBy("name", "asc").get();

    const headers = [...DEFAULT_HEADERS];
    const rows = toRowsFromDocs(snap.docs);
    return NextResponse.json({ headers, rows }, { status: 200 });
  } catch (e: any) {
    console.error("[admin/products GET] error:", e);
    return NextResponse.json(
      { headers: [...DEFAULT_HEADERS], rows: [], error: e?.message || "Failed to load products" },
      { status: 200 }
    );
  }
}

export async function POST(req: NextRequest) {
  const unauthorized = await requireAdmin(req);
  if (unauthorized) return unauthorized;

  try {
    const body = await req.json().catch(() => null);
    const headers: string[] = Array.isArray(body?.headers) ? body.headers : [];
    const rows: string[][] = Array.isArray(body?.rows) ? body.rows : [];
    if (headers.length === 0) {
      return NextResponse.json({ ok: false, error: "Missing headers" }, { status: 400 });
    }

    // Ensure at least our default columns exist
    const headerSet = new Set(headers.map((h) => h.toLowerCase()));
    DEFAULT_HEADERS.forEach((h) => {
      if (!headerSet.has(h)) headers.push(h);
    });

    const db = getDb();
    const batch = db.batch();

    const docs = toObjectsFromRows(headers, rows);
    for (const { id, data } of docs) {
      const ref = db.collection("products").doc(id);
      batch.set(ref, data, { merge: true });
    }

    await batch.commit();
    return NextResponse.json({ ok: true }, { status: 200 });
  } catch (e: any) {
    console.error("[admin/products POST] error:", e);
    return NextResponse.json({ ok: false, error: e?.message || "Failed to save products" }, { status: 200 });
  }
}
