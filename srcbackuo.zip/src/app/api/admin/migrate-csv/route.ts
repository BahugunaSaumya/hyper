// src/app/api/admin/migrate-csv/route.ts
import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "../_lib/auth";
import { getDb } from "@/lib/firebaseAdmin";

function parseCsv(text: string): string[][] {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => l.split(",").map((c) => c.trim()));
}

export async function POST(req: NextRequest) {
  const unauthorized = await requireAdmin(req);
  if (unauthorized) return unauthorized;

  try {
    // read from public
    const csvUrl = new URL("/assets/hyper-products-sample.csv", req.url).toString();
    const res = await fetch(csvUrl);
    if (!res.ok) {
      return NextResponse.json({ ok: false, error: "/assets/hyper-products-sample.csv not found" }, { status: 404 });
    }
    const text = await res.text();
    const rows = parseCsv(text);
    if (rows.length === 0) {
      return NextResponse.json({ ok: false, error: "CSV empty" }, { status: 400 });
    }

    const headers = rows[0];
    const idxId = headers.findIndex((h) => h.toLowerCase() === "id");
    if (idxId < 0) {
      return NextResponse.json({ ok: false, error: "CSV must include an 'id' column" }, { status: 400 });
    }

    const db = getDb();
    const batch = db.batch();
    let count = 0;

    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const id = (row[idxId] || "").trim();
      if (!id) continue;

      const data: Record<string, any> = {};
      headers.forEach((h, j) => {
        if (h.toLowerCase() === "id") return;
        data[h] = row[j] ?? "";
      });

      // numeric normalization
      if ("price" in data && data.price !== "") {
        const n = Number(String(data.price).replace(/[^\d.]/g, ""));
        if (!Number.isNaN(n)) data.price = n;
      }
      if (!("quantity" in data)) data.quantity = 0;
      if ("quantity" in data && data.quantity !== "") {
        const q = parseInt(String(data.quantity), 10);
        if (!Number.isNaN(q)) data.quantity = q;
      }

      const ref = db.collection("products").doc(id);
      batch.set(ref, data, { merge: true });
      count++;
    }

    await batch.commit();
    return NextResponse.json({ ok: true, count }, { status: 200 });
  } catch (e: any) {
    console.error("[migrate-csv] error:", e);
    return NextResponse.json({ ok: false, error: e?.message || "Failed to migrate CSV" }, { status: 500 });
  }
}
