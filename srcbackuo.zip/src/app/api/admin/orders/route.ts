// src/app/api/admin/orders/route.ts
import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "../_lib/auth";
import { getDb } from "@/lib/firebaseAdmin";

export async function GET(req: NextRequest) {
  const unauthorized = await requireAdmin(req);
  if (unauthorized) return unauthorized;

  try {
    const db = getDb();
    const { searchParams } = new URL(req.url);
    const limit = Math.max(1, Math.min(200, Number(searchParams.get("limit") || 50)));

    const snap = await db.collection("orders").orderBy("placedAt", "desc").limit(limit).get();

    // Keep your UI's expected shape
    const orders = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    return NextResponse.json({ orders }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json({ orders: [], error: e?.message || "Failed to load orders" }, { status: 200 });
  }
}
