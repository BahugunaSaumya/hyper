// src/app/api/admin/_lib/auth.ts
import { NextRequest, NextResponse } from "next/server";
import { ADMIN_EMAILS, ADMIN_UIDS } from "@/config/admin";
import { getAdminApp } from "@/lib/firebaseAdmin";

export async function requireAdmin(req: NextRequest) {
  const auth = req.headers.get("authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";

  let uid = "";
  let email = "";

  try {
    const admin = getAdminApp();
    if (token) {
      const decoded = await admin.auth().verifyIdToken(token);
      uid = decoded.uid || "";
      email = decoded.email || "";
    }
  } catch {
    // If Admin SDK not configured correctly, we still allow allow-list fallback below
  }

  const allowed =
    (!!email && ADMIN_EMAILS.includes(email)) ||
    (!!uid && ADMIN_UIDS.includes(uid));

  if (!allowed) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  return null;
}
