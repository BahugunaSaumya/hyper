// src/config/admin.ts
export const ADMIN_EMAILS = [
  "shanubahuguna@gmail.com" // Optional extra admins
].map(e => e.trim().toLowerCase());
