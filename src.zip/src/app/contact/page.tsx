import ContactSection from "@/components/ContactSection";
export default function ContactPage() {
  return <main className="offset-header"><ContactSection /></main>;
}
