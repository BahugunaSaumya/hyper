import LoadingScreen from "@/components/LoadingScreen";

export default function AppLoading() {
  return <LoadingScreen />;
}
