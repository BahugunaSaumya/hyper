// src/app/api/reviews/upload/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getAuth } from "firebase-admin/auth";
import { getStorageBucket } from "@/lib/firebaseAdmin";

export const runtime = "nodejs";

const MAX_FILES = 6;
const MAX_BYTES_PER_FILE = 5 * 1024 * 1024; // 5MB

function extFromType(type: string | null) {
  const t = (type || "").toLowerCase();
  if (t.includes("png")) return ".png";
  if (t.includes("webp")) return ".webp";
  if (t.includes("jpeg") || t.includes("jpg")) return ".jpg";
  return ".jpg";
}

export async function POST(req: NextRequest) {
  try {
    // auth
    const m = (req.headers.get("authorization") || "").match(/^Bearer\s+(.+)$/i);
    if (!m) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const tok = await getAuth().verifyIdToken(m[1]);
    const userId = tok.uid;

    // form-data
    const form = await req.formData().catch(() => null);
    if (!form) return NextResponse.json({ error: "Invalid form-data" }, { status: 400 });
    const productId = String(form.get("productId") || "").trim();
    if (!productId) return NextResponse.json({ error: "Missing productId" }, { status: 400 });

    const files: File[] = [];
    for (const [k, v] of form.entries()) {
      if (k === "images" && v instanceof File) files.push(v);
    }
    if (!files.length) return NextResponse.json({ error: "No image files" }, { status: 400 });

    const bucket = getStorageBucket(); // <-- uses env var

    const now = Date.now();
    const urls: string[] = [];

    for (let i = 0; i < Math.min(files.length, MAX_FILES); i++) {
      const f = files[i];
      if (f.size > MAX_BYTES_PER_FILE) {
        return NextResponse.json({ error: `File ${f.name} too large (max 5MB)` }, { status: 400 });
      }
      const contentType = f.type || "image/jpeg";
      const ext = extFromType(contentType);
      const path = `reviews/${productId}/${userId}/${now}_${i}${ext}`;

      // Generate a token so we can build a stable download URL
      const token =
        (globalThis.crypto?.randomUUID?.() as string) ||
        Math.random().toString(36).slice(2);

      await bucket.file(path).save(Buffer.from(await f.arrayBuffer()), {
        contentType,
        resumable: false,
        public: false,
        metadata: {
          metadata: { firebaseStorageDownloadTokens: token },
        },
      });

      const url = `https://firebasestorage.googleapis.com/v0/b/${bucket.name}/o/${encodeURIComponent(
        path
      )}?alt=media&token=${token}`;

      urls.push(url);
    }

    return NextResponse.json({ ok: true, urls }, { status: 200 });
  } catch (e: any) {
    console.error("[reviews/upload] fatal:", e?.message || e);
    return NextResponse.json(
      { error: "Bucket misconfigured or server error" },
      { status: 500 }
    );
  }
}
