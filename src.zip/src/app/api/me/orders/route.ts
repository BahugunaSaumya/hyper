// src/app/api/me/orders/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getAuth } from "firebase-admin/auth";
import { getDb } from "@/lib/firebaseAdmin";

export const runtime = "nodejs";

function toDate(v: any): Date | null {
  try {
    if (!v) return null;
    if (v instanceof Date) return isNaN(v.getTime()) ? null : v;
    if (typeof v?.toDate === "function") {
      const d = v.toDate();
      return isNaN(d.getTime()) ? null : d;
    }
    if (typeof v?.seconds === "number") return new Date(v.seconds * 1000);
    if (typeof v?._seconds === "number") return new Date(v._seconds * 1000);
    const d = new Date(v);
    return isNaN(d.getTime()) ? null : d;
  } catch {
    return null;
  }
}
function tsMs(v: any): number {
  const d = toDate(v);
  return d ? d.getTime() : 0;
}

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get("authorization") || "";
    const m = authHeader.match(/^Bearer\s+(.+)$/i);
    if (!m) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const tok = await getAuth().verifyIdToken(m[1]);
    const uid = tok.uid;
    const emailLower = (tok.email || "").toLowerCase();

    const url = new URL(req.url);
    const limit = Math.max(1, Math.min(100, Number(url.searchParams.get("limit") || 50)));
    const cursorMs = url.searchParams.get("cursor");
    const cursorDate = cursorMs ? new Date(Number(cursorMs)) : null;

    const db = getDb();
    const col = db.collection("orders");

    // Helper to normalize a doc into the shape your UI expects
    const normalize = (snap: FirebaseFirestore.QueryDocumentSnapshot) => {
      const d = snap.data() || {};
      return { id: snap.id, ...d };
    };

    // ----------------------------
    // 1) Try ownerUid + orderBy createdAt DESC (requires composite index)
    // ----------------------------
    try {
      let q: FirebaseFirestore.Query = col.where("ownerUid", "==", uid).orderBy("createdAt", "desc");
      if (cursorDate) q = q.startAfter(cursorDate);
      q = q.limit(limit);

      const snap = await q.get();
      if (!snap.empty) {
        return NextResponse.json({
          orders: snap.docs.map(normalize),
          nextCursor:
            snap.size === limit ? String(tsMs(snap.docs[snap.docs.length - 1].get("createdAt"))) : null,
        });
      }
    } catch (e: any) {
      // If it's an index error, we will fall back below. Otherwise rethrow.
      const msg = String(e?.message || e);
      const code = e?.code || e?.status || "";
      const isIndexErr = /FAILED_PRECONDITION/i.test(msg) || /indexes/i.test(msg) || code === 9;
      if (!isIndexErr) throw e;
    }

    // ----------------------------
    // 2) Fallback A: ownerEmailLower + orderBy createdAt DESC (may also need index)
    // ----------------------------
    try {
      if (emailLower) {
        let q: FirebaseFirestore.Query = col
          .where("ownerEmailLower", "==", emailLower)
          .orderBy("createdAt", "desc");
        if (cursorDate) q = q.startAfter(cursorDate);
        q = q.limit(limit);

        const snap = await q.get();
        if (!snap.empty) {
          return NextResponse.json({
            orders: snap.docs.map(normalize),
            nextCursor:
              snap.size === limit ? String(tsMs(snap.docs[snap.docs.length - 1].get("createdAt"))) : null,
          });
        }
      }
    } catch (e: any) {
      // swallow to proceed to no-index fallback
      const msg = String(e?.message || e);
      const code = e?.code || e?.status || "";
      const isIndexErr = /FAILED_PRECONDITION/i.test(msg) || /indexes/i.test(msg) || code === 9;
      if (!isIndexErr) throw e;
    }

    // ----------------------------
    // 3) FINAL FALLBACK (no composite index needed):
    //    - query by equality ONLY (ownerUid or ownerEmailLower)
    //    - sort in memory by createdAt desc
    //    - cursor handled in memory
    // ----------------------------
    let snaps: FirebaseFirestore.QuerySnapshot | null = null;

    if (uid) {
      snaps = await col.where("ownerUid", "==", uid).limit(500).get();
    }
    if ((!snaps || snaps.empty) && emailLower) {
      snaps = await col.where("ownerEmailLower", "==", emailLower).limit(500).get();
    }
    const all = (snaps?.docs || []).map(normalize);

    // Sort + in-memory cursor window
    all.sort((a: any, b: any) => tsMs(b.createdAt) - tsMs(a.createdAt));

    const startIdx = cursorDate ? all.findIndex((d: any) => tsMs(d.createdAt) < cursorDate.getTime()) : 0;
    const slice = all.slice(startIdx < 0 ? 0 : startIdx, (startIdx < 0 ? 0 : startIdx) + limit);

    const next =
      startIdx + limit < all.length ? String(tsMs(all[startIdx + limit - 1]?.createdAt)) : null;

    return NextResponse.json({ orders: slice, nextCursor: next });
  } catch (err: any) {
    console.error("[/api/me/orders] error:", err?.message || err);
    return NextResponse.json({ error: "Failed to load orders" }, { status: 500 });
  }
}
