// src/app/api/me/address/route.ts
export { GET, PUT, runtime } from "../profile/route";
