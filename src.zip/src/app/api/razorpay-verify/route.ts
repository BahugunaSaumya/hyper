import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@/lib/firebaseAdmin";
import { sendOrderEmails } from "@/lib/email";

export const runtime = "nodejs";

/**
 * MOCK + PROD-READY SHAPE
 * - Dev: can post just { orderId }; we auto-fill Razorpay fields.
 * - Prod later: post { orderId, razorpay_order_id, razorpay_payment_id, razorpay_signature } from real checkout.
 * - Marks order "paid".
 * - Sends exactly two emails (customer + admin) once per order (idempotent).
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      orderId,                 // Firestore orders/<orderId>
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
    } = body || {};

    if (!orderId) {
      return NextResponse.json({ error: "Missing orderId" }, { status: 400 });
    }

    const db = getDb();
    const ref = db.collection("orders").doc(String(orderId));

    // --- Load current order (to know if we already emailed) ---
    const currentSnap = await ref.get();
    if (!currentSnap.exists) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }
    const current = currentSnap.data() || {};

    // --- In dev/mock, auto-fill missing Razorpay fields ---
    const now = Date.now();
    const isMock = process.env.NODE_ENV !== "production";
    const rp_order_id   = razorpay_order_id   || (isMock ? `order_mock_${now}` : null);
    const rp_payment_id = razorpay_payment_id || (isMock ? `pay_mock_${now}`   : null);
    const rp_signature  = razorpay_signature  || (isMock ? `sig_mock_${now}`   : null);

    // In prod, require the fields
    if (!isMock && (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature)) {
      return NextResponse.json({ error: "Missing Razorpay verification fields" }, { status: 400 });
    }

    // --- Mark paid (idempotent-friendly merge) ---
    await ref.set(
      {
        status: "paid",
        updatedAt: new Date(),
        payment: {
          ...(current.payment || {}),
          provider: "razorpay",
          status: "paid",
          razorpay_order_id: rp_order_id,
          razorpay_payment_id: rp_payment_id,
          razorpay_signature: rp_signature,
          verifiedAt: new Date(),
          mode: isMock ? "mock" : "live",
        },
      },
      { merge: true }
    );

    // --- Send exactly two emails once (idempotent) ---
    const afterSnap = await ref.get();
    const order = { id: afterSnap.id, ...(afterSnap.data() || {}) };

    // Only send if we haven't already
    if (!order.emails?.sent) {
      try {
        await sendOrderEmails(String(orderId), order); // implement this to send to user + admin in one call
        await ref.set(
          {
            emails: {
              ...(order.emails || {}),
              sent: true,
              sentAt: new Date(),
              type: "payment_paid", // helpful if you add other email moments later
            },
          },
          { merge: true }
        );
      } catch (e) {
        // Do not fail the API if email sending fails; you can requeue separately
        console.error("[verify] email error:", e);
      }
    }

    return NextResponse.json(
      {
        success: true,
        verified: true,
        mode: isMock ? "mock" : "live",
        message: "Order marked paid. Emails sent if not previously sent.",
        order_id: rp_order_id,
        payment_id: rp_payment_id,
        alreadyEmailed: Boolean(order.emails?.sent),
      },
      { status: 200 }
    );
  } catch (err: any) {
    console.error("[verify] fatal:", err?.message || err);
    return NextResponse.json({ error: "Unable to verify payment" }, { status: 500 });
  }
}
