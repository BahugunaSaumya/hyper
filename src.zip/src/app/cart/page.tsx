// app/cart/page.tsx
"use client";

import CartView from "@/components/CartView";

export default function CartPage() {
  return <CartView />;
}
