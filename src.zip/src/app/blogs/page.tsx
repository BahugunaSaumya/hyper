import BlogsSection from "@/components/BlogsSection";
export default function BlogsPage() {
  return <main className="offset-header"><BlogsSection /></main>;
}
