import CheckoutView from "@/components/CheckoutView";
export default function Page() {
  return <CheckoutView />;
}
