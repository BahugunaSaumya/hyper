declare module "react-player" {
    const ReactPlayer: any;
    export default ReactPlayer;
}
