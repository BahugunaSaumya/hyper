// src/lib/email.ts
import { Resend } from "resend";

type AnyOrder = Record<string, any>;

export function assertEmailEnv() {
  const required = ["RESEND_API_KEY", "FROM_EMAIL", "ADMIN_EMAIL"] as const;
  const missing = required.filter((k) => !process.env[k]);
  if (missing.length) {
    throw new Error(`[email] Missing env: ${missing.join(", ")}`);
  }
}

export async function sendOrderEmails(orderId: string, order: AnyOrder) {
  assertEmailEnv();

  // lightweight inline renderer to avoid importing route file
  const inr = (n: any) =>
    new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(Number(n || 0));

  const rows = (Array.isArray(order.items) ? order.items : []).map((it: any) => {
    const name = it.title || it.name || it.slug || it.id || "Item";
    const qty = it.qty || it.quantity || 1;
    const price = it.price || it.amount || it.total || 0;
    return `<tr>
      <td style="padding:8px 12px;border:1px solid #eee">${name}</td>
      <td style="padding:8px 12px;border:1px solid #eee;text-align:center">${qty}</td>
      <td style="padding:8px 12px;border:1px solid #eee;text-align:right">${inr(price)}</td>
    </tr>`;
  }).join("");

  const subtotal = order.subtotal ?? order.amounts?.subtotal ?? order.total ?? 0;
  const shipping = order.shipping ?? order.amounts?.shipping ?? 0;
  const total = order.total ?? order.amounts?.total ?? subtotal + shipping;

  const customerHtml = `
    <div style="font-family:Inter,system-ui,Arial,sans-serif">
      <h2>Thanks for your order, ${order?.customer?.name || "there"}!</h2>
      <p>Order <b>${orderId}</b> was received and payment verified.</p>
      <table style="border-collapse:collapse;font-size:14px">
        <thead>
          <tr>
            <th style="padding:8px 12px;border:1px solid #eee;text-align:left">Product</th>
            <th style="padding:8px 12px;border:1px solid #eee;text-align:center">Qty</th>
            <th style="padding:8px 12px;border:1px solid #eee;text-align:right">Price</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
        <tfoot>
          <tr><td colspan="2" style="padding:8px 12px;border:1px solid #eee;text-align:right">Subtotal</td><td style="padding:8px 12px;border:1px solid #eee;text-align:right">${inr(subtotal)}</td></tr>
          <tr><td colspan="2" style="padding:8px 12px;border:1px solid #eee;text-align:right">Shipping</td><td style="padding:8px 12px;border:1px solid #eee;text-align:right">${inr(shipping)}</td></tr>
          <tr><td colspan="2" style="padding:8px 12px;border:1px solid #eee;text-align:right"><b>Total</b></td><td style="padding:8px 12px;border:1px solid #eee;text-align:right"><b>${inr(total)}</b></td></tr>
        </tfoot>
      </table>
      <p style="font-size:12px;color:#666">We’ll email you again when your order ships.</p>
    </div>
  `;

  const adminHtml = `
    <div style="font-family:Inter,system-ui,Arial,sans-serif">
      <h2>New order: ${orderId}</h2>
      <p><b>Name:</b> ${order?.customer?.name || "-"}<br/>
         <b>Email:</b> ${order?.customer?.email || "-"}<br/>
         <b>Phone:</b> ${order?.customer?.phone || "-"}<br/>
         <b>Total:</b> ${inr(total)}<br/>
         <b>Payment:</b> ${order?.payment?.provider || "razorpay"} / ${order?.payment?.status || "paid"}</p>
      <pre style="font-size:12px;background:#fafafa;border:1px solid #eee;padding:10px;border-radius:8px;overflow:auto">${JSON.stringify(order, null, 2)}</pre>
    </div>
  `;

  const resend = new Resend(process.env.RESEND_API_KEY);
  const results: Array<{ type: "customer" | "admin"; id?: string; error?: any }> = [];

  // customer
  if (order?.customer?.email) {
    const r = await resend.emails.send({
      from: process.env.FROM_EMAIL!,
      to: order.customer.email,
      subject: `Your order ${orderId} is confirmed`,
      html: customerHtml,
      replyTo: process.env.ADMIN_EMAIL,
    });
    if (r.error) results.push({ type: "customer", error: r.error }); else results.push({ type: "customer", id: r.data?.id });
  }

  // admin
  const adminTo = process.env.ADMIN_EMAIL;
  if (adminTo) {
    const r = await resend.emails.send({
      from: process.env.FROM_EMAIL!,
      to: adminTo,
      subject: `New order: ${orderId}`,
      html: adminHtml,
    });
    if (r.error) results.push({ type: "admin", error: r.error }); else results.push({ type: "admin", id: r.data?.id });
  }

  return results;
}
