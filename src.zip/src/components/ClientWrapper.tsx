// src/components/ClientWrapper.tsx
"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";

export default function ClientWrapper({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [bodyClass, setBodyClass] = useState("");

  useEffect(() => {
    console.log("set body to home" + pathname)
    setBodyClass(pathname === "/" ? "home" : "");
  }, [pathname]);

  return <div className={bodyClass}>{children}</div>;
}
